/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Camera, 
  Upload, 
  ImageIcon, 
  Download, 
  RefreshCw, 
  CheckCircle2,
  Loader2,
  X,
  ChevronRight,
  User,
  Briefcase,
  Wifi,
  Battery,
  Signal,
  Sparkles,
  ArrowRight,
  Layers,
  Zap,
  ArrowLeft,
  MoreVertical,
  History,
  Settings,
  Image as LucideImage
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Initialize Gemini AI
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

type Step = 'landing' | 'preview' | 'loading' | 'results';

interface ImageState {
  url: string;
  base64: string;
  mimeType: string;
}

interface ResultImage {
  id: string;
  title: string;
  url: string;
  base64: string;
}

// Material Design 3 Color Palette (Light)
const M3_COLORS = {
  primary: '#6750A4',
  onPrimary: '#FFFFFF',
  primaryContainer: '#EADDFF',
  onPrimaryContainer: '#21005D',
  secondary: '#625B71',
  onSecondary: '#FFFFFF',
  secondaryContainer: '#E8DEF8',
  onSecondaryContainer: '#1D192B',
  tertiary: '#7D5260',
  onTertiary: '#FFFFFF',
  tertiaryContainer: '#FFD8E4',
  onTertiaryContainer: '#31111D',
  surface: '#FEF7FF',
  onSurface: '#1D1B20',
  surfaceVariant: '#E7E0EB',
  onSurfaceVariant: '#49454F',
  outline: '#79747E',
  error: '#B3261E',
  onError: '#FFFFFF',
};

// Enhanced Prompts for High Clarity and Brighter Faces
const PROMPTS = {
  executive: "Transform this person into a formal Executive Headshot. Straight-on angle, professional studio lighting with a focus on a bright, clear face. Plain light background, natural expression. Professional attire. Ultra-realistic, 8k resolution, sharp focus, high clarity, HD.",
  corporateFullBody: "Transform this person into a Corporate Full Body portrait. Standing posture, professional business attire, neutral indoor office background. Bright, clean lighting with a well-lit face. Full-body shot. Ultra-realistic, 8k resolution, high clarity, HD.",
  beachFace: "Transform this person into a Beach Face medium close-up portrait. Natural seaside environment, soft sunset or daylight lighting that illuminates the face brightly. Relaxed and confident expression. Ultra-realistic, 8k resolution, high clarity, HD.",
  lifestyleProfessional: "Transform this person into a Lifestyle Professional medium shot. Seated at a desk with a laptop, neutral daylight from a window providing a bright, clear facial glow. Relaxed but competent expression. Ultra-realistic, 8k resolution, high clarity, HD.",
  officeLook: "Transform this person into an Office Look upper body portrait. Formal or smart business attire, modern office interior. Soft but bright indoor lighting for a clear face. Focused working expression. Ultra-realistic, 8k resolution, high clarity, HD.",
  travelLook: "Transform this person into a Travel Look medium shot. Airport or urban travel backdrop, smart casual outfit. Natural daylight highlighting the face. Confident explorer vibe. Ultra-realistic, 8k resolution, high clarity, HD.",
  partyLook: "Transform this person into a Party Look upper body portrait. Evening ambient lighting with warm, bright facial highlights. Elegant attire, social expression. Ultra-realistic, 8k resolution, high clarity, HD.",
  weddingLook: "Transform this person into a Wedding Look portrait shot. Ethnic or formal celebration attire, soft festive lighting with a bright, clear face. Elegant background. Ultra-realistic, 8k resolution, high clarity, HD.",
  leadershipPortrait: "Transform this person into a Leadership Portrait 3/4 profile shot. Slightly turned head, warm golden-hour lighting that makes the face pop. Blurred background, visionary expression. Ultra-realistic, 8k resolution, high clarity, HD.",
  collegeStudent: "Transform this person into a College Going Student casual portrait. Youthful relaxed outfit, campus-style environment. Natural daylight for a bright, energetic facial appearance. Ultra-realistic, 8k resolution, high clarity, HD."
};

const STYLE_PREVIEWS: Record<string, string> = {
  executive: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=300",
  corporateFullBody: "https://images.unsplash.com/photo-1480455624313-e29b44bbfde1?auto=format&fit=crop&q=80&w=300",
  beachFace: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=300",
  lifestyleProfessional: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&q=80&w=300",
  officeLook: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=300",
  travelLook: "https://images.unsplash.com/photo-1488085061387-422e29b40080?auto=format&fit=crop&q=80&w=300",
  partyLook: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&q=80&w=300",
  weddingLook: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=300",
  leadershipPortrait: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=300",
  collegeStudent: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80&w=300"
};

export default function App() {
  const [step, setStep] = useState<Step>('landing');
  const [originalImage, setOriginalImage] = useState<ImageState | null>(null);
  const [results, setResults] = useState<ResultImage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [selectedVariations, setSelectedVariations] = useState<string[]>(Object.keys(PROMPTS));
  const [loadingProgress, setLoadingProgress] = useState<string>('');

  const toggleVariation = (key: string) => {
    setSelectedVariations(prev => 
      prev.includes(key) 
        ? prev.filter(k => k !== key) 
        : [...prev, key]
    );
  };

  const processFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = (e.target?.result as string).split(',')[1];
      setOriginalImage({
        url: URL.createObjectURL(file),
        base64,
        mimeType: file.type
      });
      setStep('preview');
      setError(null);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      setError('Could not access camera. Please check permissions.');
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg');
        const base64 = dataUrl.split(',')[1];
        
        // Stop camera
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
        setIsCameraActive(false);

        setOriginalImage({
          url: dataUrl,
          base64,
          mimeType: 'image/jpeg'
        });
        setStep('preview');
      }
    }
  };

  const generateHeadshots = async () => {
    if (!originalImage || selectedVariations.length === 0) {
      setError('Please select at least one variation.');
      return;
    }

    setStep('loading');
    setError(null);
    setLoadingProgress('Starting generation...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const promptEntries = Object.entries(PROMPTS).filter(([key]) => selectedVariations.includes(key));
      const newResults: ResultImage[] = [];

      // Process sequentially to avoid 429 Resource Exhausted errors
      for (let i = 0; i < promptEntries.length; i++) {
        const [key, promptText] = promptEntries[i];
        const title = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        setLoadingProgress(`Generating ${title} (${i + 1}/${promptEntries.length})...`);

        let retryCount = 0;
        const maxRetries = 5;
        let success = false;

        while (retryCount < maxRetries && !success) {
          try {
            const res = await ai.models.generateContent({
              model: 'gemini-2.5-flash-image',
              contents: { 
                parts: [
                  { inlineData: { data: originalImage.base64, mimeType: originalImage.mimeType } }, 
                  { text: promptText }
                ] 
              },
            });

            for (const part of res.candidates?.[0]?.content?.parts || []) {
              if (part.inlineData) {
                const base64 = part.inlineData.data;
                const mimeType = part.inlineData.mimeType || 'image/png';
                newResults.push({
                  id: key,
                  title,
                  url: `data:${mimeType};base64,${base64}`,
                  base64
                });
                success = true;
                break;
              }
            }
          } catch (e: any) {
            console.error(`Error generating ${key} (Attempt ${retryCount + 1}):`, e);
            const isRateLimit = e.message?.includes('429') || e.status === 429 || e.message?.includes('RESOURCE_EXHAUSTED');
            
            if (isRateLimit) {
              retryCount++;
              if (retryCount < maxRetries) {
                // More aggressive backoff: 2s, 4s, 8s, 16s
                const delay = Math.pow(2, retryCount) * 1000; 
                setLoadingProgress(`Limit reached. Pausing for ${delay/1000}s to let the API reset...`);
                await new Promise(resolve => setTimeout(resolve, delay));
              }
            } else {
              // Non-429 error (e.g. safety filters), skip this one and continue
              console.warn(`Skipping ${key} due to non-retryable error.`);
              break;
            }
          }
        }

        // Increased delay between successful requests to 1.2s to stay under RPM limits
        if (i < promptEntries.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1200));
        }
      }

      if (newResults.length === 0) {
        throw new Error('Failed to generate headshots. Please try again.');
      }

      setResults(newResults);
      setStep('results');
    } catch (err: any) {
      console.error('Generation error:', err);
      setError(err.message || 'An error occurred while generating your headshots.');
      setStep('preview');
    } finally {
      setLoadingProgress('');
    }
  };

  const downloadImage = (img: ResultImage) => {
    const link = document.createElement('a');
    link.href = img.url;
    link.download = `faceup-${img.id}-${Date.now()}.png`;
    link.click();
  };

  const reset = () => {
    setOriginalImage(null);
    setResults([]);
    setStep('landing');
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#FDF7FF] flex items-center justify-center p-4 md:p-8 font-sans transition-colors duration-500">
      {/* iPhone Frame */}
      <div className="relative w-full max-w-[390px] h-[844px] bg-black rounded-[3.5rem] shadow-[0_0_0_12px_#1a1a1a,0_40px_100px_-20px_rgba(0,0,0,0.4)] overflow-hidden border-[8px] border-black">
        
        {/* Dynamic Island */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-32 h-8 bg-black rounded-full z-[100] flex items-center justify-center gap-2">
          <div className="w-2 h-2 bg-[#1a1a1a] rounded-full" />
          <div className="w-1 h-1 bg-[#1a1a1a] rounded-full" />
        </div>

        {/* Status Bar */}
        <div className="absolute top-0 left-0 right-0 h-12 px-8 flex items-center justify-between z-[90] text-black text-[13px] font-medium">
          <span>9:41</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-4 h-4" />
            <Wifi className="w-4 h-4" />
            <Battery className="w-5 h-5" />
          </div>
        </div>

        {/* Inner Content Container */}
        <div className="w-full h-full bg-[#FDF7FF] overflow-y-auto overflow-x-hidden scrollbar-hide pt-12">
          <AnimatePresence mode="wait">
            {step === 'landing' && (
              <motion.div 
                key="landing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="px-6 py-8 flex flex-col h-full"
              >
                {/* Top App Bar */}
                <div className="flex items-center justify-between mb-12">
                  <div className="w-10 h-10 rounded-full bg-[#EADDFF] flex items-center justify-center text-[#21005D]">
                    <User className="w-5 h-5" />
                  </div>
                  <h1 className="text-lg font-medium text-[#1D1B20]">FaceUp</h1>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-[#49454F]">
                    <Settings className="w-5 h-5" />
                  </div>
                </div>

                <div className="flex-1 flex flex-col items-center text-center space-y-10">
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: 'spring', damping: 15 }}
                    className="relative"
                  >
                    <div className="w-40 h-40 bg-[#EADDFF] rounded-[2.5rem] flex items-center justify-center shadow-lg">
                      <Sparkles className="w-20 h-20 text-[#6750A4]" />
                    </div>
                    <motion.div 
                      animate={{ y: [0, -8, 0] }}
                      transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
                      className="absolute -top-2 -right-2 w-12 h-12 bg-[#FFD8E4] rounded-2xl flex items-center justify-center shadow-md"
                    >
                      <LucideImage className="w-6 h-6 text-[#7D5260]" />
                    </motion.div>
                  </motion.div>
                  
                  <div className="space-y-3">
                    <h2 className="text-4xl font-bold text-[#1D1B20] tracking-tight">
                      Professional <span className="text-[#6750A4]">Portraits</span>
                    </h2>
                    <p className="text-base text-[#49454F] font-medium max-w-[280px] mx-auto leading-relaxed">
                      Transform your photos into studio-quality headshots using Google's advanced AI.
                    </p>
                  </div>

                  <div className="w-full space-y-3 pt-6">
                    {/* M3 Filled Button */}
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-4 px-6 bg-[#6750A4] text-white rounded-full font-medium text-base flex items-center justify-center gap-3 shadow-md hover:shadow-lg transition-all"
                    >
                      <Upload className="w-5 h-5" />
                      Upload Photo
                    </motion.button>
                    
                    {/* M3 Tonal Button */}
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={startCamera}
                      className="w-full py-4 px-6 bg-[#EADDFF] text-[#21005D] rounded-full font-medium text-base flex items-center justify-center gap-3 hover:bg-[#DBCBFF] transition-all"
                    >
                      <Camera className="w-5 h-5" />
                      Take Photo
                    </motion.button>
                  </div>
                </div>

                {/* Bottom Navigation-like indicator */}
                <div className="pt-12 flex justify-center gap-8 opacity-40">
                  <div className="flex flex-col items-center gap-1">
                    <History className="w-5 h-5" />
                    <span className="text-[10px] font-medium">History</span>
                  </div>
                  <div className="flex flex-col items-center gap-1 text-[#6750A4]">
                    <Sparkles className="w-5 h-5" />
                    <span className="text-[10px] font-medium">Create</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <LucideImage className="w-5 h-5" />
                    <span className="text-[10px] font-medium">Gallery</span>
                  </div>
                </div>

                {isCameraActive && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute inset-0 z-[110] bg-black flex flex-col items-center justify-center"
                  >
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                    <div className="absolute bottom-16 flex items-center gap-8">
                      <button 
                        onClick={() => {
                          const stream = videoRef.current?.srcObject as MediaStream;
                          stream.getTracks().forEach(track => track.stop());
                          setIsCameraActive(false);
                        }}
                        className="w-14 h-14 bg-white/10 backdrop-blur-lg rounded-full flex items-center justify-center text-white border border-white/20"
                      >
                        <X className="w-6 h-6" />
                      </button>
                      <button 
                        onClick={capturePhoto}
                        className="w-20 h-20 bg-white rounded-full border-[4px] border-white/30 flex items-center justify-center shadow-2xl"
                      >
                        <div className="w-14 h-14 bg-[#6750A4] rounded-full" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {step === 'preview' && originalImage && (
              <motion.div 
                key="preview"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col h-full"
              >
                {/* Fixed Top App Bar */}
                <div className="px-6 pt-6 pb-4 flex items-center justify-between bg-[#FDF7FF] z-10">
                  <button onClick={reset} className="w-10 h-10 flex items-center justify-center hover:bg-[#E7E0EB] rounded-full transition-colors">
                    <ArrowLeft className="w-6 h-6 text-[#1D1B20]" />
                  </button>
                  <h2 className="text-lg font-medium text-[#1D1B20]">Customize Styles</h2>
                  <button className="w-10 h-10 flex items-center justify-center hover:bg-[#E7E0EB] rounded-full transition-colors">
                    <MoreVertical className="w-6 h-6 text-[#49454F]" />
                  </button>
                </div>

                {/* Scrollable Content Area */}
                <div className="flex-1 overflow-y-auto scrollbar-hide">
                  <div className="px-6 pt-2 pb-12">
                    {/* Image Preview */}
                    <div className="flex flex-col items-center mb-10">
                      <div className="relative group">
                        <div className="relative w-36 h-36 rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white transform transition-transform duration-300 group-hover:scale-105">
                          <img src={originalImage.url} alt="Original" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                        <div className="absolute -bottom-2 -right-2 w-11 h-11 bg-[#6750A4] rounded-2xl flex items-center justify-center text-white shadow-lg border-2 border-white">
                          <LucideImage className="w-5 h-5" />
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="mt-6 flex items-center gap-2 px-6 py-2.5 bg-[#EADDFF] rounded-full text-sm font-bold text-[#21005D] hover:bg-[#DBCBFF] transition-all active:scale-95"
                      >
                        <RefreshCw className="w-4 h-4" />
                        Replace Image
                      </button>
                    </div>

                    <div className="space-y-6">
                      <div className="flex items-center justify-between px-1">
                        <div className="space-y-0.5">
                          <p className="text-sm font-bold text-[#1D1B20]">Select Personas</p>
                          <p className="text-[11px] text-[#49454F]">Choose styles for your headshots</p>
                        </div>
                        <button 
                          onClick={() => setSelectedVariations(selectedVariations.length === Object.keys(PROMPTS).length ? [] : Object.keys(PROMPTS))}
                          className="text-xs font-bold text-[#6750A4] bg-[#6750A4]/5 px-4 py-2 rounded-full hover:bg-[#6750A4]/10 transition-colors"
                        >
                          {selectedVariations.length === Object.keys(PROMPTS).length ? 'Deselect All' : 'Select All'}
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                      {Object.keys(PROMPTS).map((key) => {
                        const isSelected = selectedVariations.includes(key);
                        const title = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
                        const previewUrl = STYLE_PREVIEWS[key];
                        
                        return (
                          <motion.button 
                            key={key} 
                            whileTap={{ scale: 0.97 }}
                            onClick={() => toggleVariation(key)}
                            className={`relative group flex flex-col items-start gap-3 p-3 rounded-3xl transition-all border-2 h-40 overflow-hidden ${
                              isSelected 
                                ? 'border-[#6750A4] shadow-lg ring-1 ring-[#6750A4]' 
                                : 'border-[#E7E0EB] hover:border-[#6750A4]/30'
                            }`}
                          >
                            {/* Background Image */}
                            <div className="absolute inset-0 z-0">
                              <img 
                                src={previewUrl} 
                                alt={title} 
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = `https://picsum.photos/seed/${key}/400/400`;
                                }}
                                className={`w-full h-full object-cover transition-opacity duration-300 ${
                                  isSelected ? 'opacity-40 scale-105' : 'opacity-90'
                                }`}
                                referrerPolicy="no-referrer"
                              />
                              {/* Selection Overlay */}
                              {isSelected && (
                                <div className="absolute inset-0 bg-[#6750A4]/20 mix-blend-overlay" />
                              )}
                            </div>

                            {/* Selection Indicator */}
                            <div className={`relative z-10 w-9 h-9 rounded-2xl flex items-center justify-center transition-all duration-200 shadow-md ${
                              isSelected ? 'bg-[#6750A4] text-white' : 'bg-white/95 text-[#49454F]'
                            }`}>
                              {isSelected ? <CheckCircle2 className="w-5 h-5" /> : <Layers className="w-4 h-4" />}
                            </div>
                            
                            {/* Title */}
                            <div className="relative z-10 mt-auto w-full text-left">
                              <span className="block text-[14px] font-bold leading-tight text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
                                {title}
                              </span>
                            </div>
                          </motion.button>
                        );
                      })}
                      </div>
                    </div>

                    {/* Generate Button - Moved inside scrollable area to fix spacing */}
                    <div className="mt-12">
                      <motion.button 
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        onClick={generateHeadshots}
                        disabled={selectedVariations.length === 0}
                        className={`w-full py-4 rounded-full font-bold text-base flex items-center justify-center gap-3 transition-all shadow-lg ${
                          selectedVariations.length > 0 
                            ? 'bg-[#6750A4] text-white shadow-[#6750A4]/20' 
                            : 'bg-[#E7E0EB] text-[#49454F] cursor-not-allowed shadow-none'
                        }`}
                      >
                        <Sparkles className="w-5 h-5" />
                        Generate {selectedVariations.length} Styles
                      </motion.button>
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="fixed bottom-28 left-1/2 -translate-x-1/2 w-[85%] p-4 bg-[#FFDAD6] text-[#410002] rounded-2xl text-xs font-bold flex items-center gap-2 shadow-xl border border-[#FFB4AB] z-50">
                    <X className="w-4 h-4 shrink-0" /> {error}
                  </div>
                )}
              </motion.div>
            )}

            {step === 'loading' && (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-[#FDF7FF] z-[100] flex flex-col items-center justify-center px-10 text-center"
              >
                <div className="relative mb-10">
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}
                    className="w-28 h-28 border-[4px] border-[#EADDFF] border-t-[#6750A4] rounded-full"
                  />
                  <div className="absolute inset-0 m-auto w-14 h-14 bg-[#6750A4] rounded-2xl flex items-center justify-center shadow-lg">
                    <Loader2 className="w-7 h-7 text-white animate-spin" />
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h2 className="text-2xl font-bold text-[#1D1B20]">Processing...</h2>
                  <p className="text-sm text-[#49454F] font-medium leading-relaxed">
                    {loadingProgress || 'Applying Material Design AI enhancements to your portrait for high clarity and brightness.'}
                  </p>
                </div>

                <div className="mt-10 w-full max-w-[180px] h-1 bg-[#EADDFF] rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ x: '-100%' }}
                    animate={{ x: '100%' }}
                    transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
                    className="w-full h-full bg-[#6750A4] rounded-full"
                  />
                </div>
              </motion.div>
            )}

            {step === 'results' && (
              <motion.div 
                key="results"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="px-6 py-6 flex flex-col h-full"
              >
                {/* Top App Bar */}
                <div className="flex items-center justify-between mb-8">
                  <button onClick={reset} className="w-10 h-10 flex items-center justify-center hover:bg-[#E7E0EB] rounded-full transition-colors">
                    <ArrowLeft className="w-6 h-6 text-[#1D1B20]" />
                  </button>
                  <h2 className="text-lg font-medium text-[#1D1B20]">Your Results</h2>
                  <button className="w-10 h-10 flex items-center justify-center hover:bg-[#E7E0EB] rounded-full transition-colors">
                    <Download className="w-6 h-6 text-[#49454F]" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto scrollbar-hide">
                  <div className="space-y-10 pb-12">
                    {results.map((img, idx) => (
                      <motion.div 
                        key={img.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: idx * 0.1 }}
                        className="space-y-4"
                      >
                        <div className="relative group w-full aspect-[4/5] rounded-3xl overflow-hidden shadow-sm border border-[#E7E0EB] bg-[#FDF7FF]">
                          <img src={img.url} alt={img.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <div className="flex items-center justify-between px-2">
                          <h3 className="font-bold text-lg text-[#1D1B20]">{img.title}</h3>
                          <button 
                            onClick={() => downloadImage(img)}
                            className="flex items-center gap-2 bg-[#EADDFF] text-[#21005D] px-5 py-2.5 rounded-full font-bold text-sm hover:bg-[#DBCBFF] transition-all active:scale-95"
                          >
                            <LucideImage className="w-4 h-4" />
                            Save
                          </button>
                        </div>
                      </motion.div>
                    ))}

                    {/* Start Over Button - Moved inside scrollable area */}
                    <div className="pt-6">
                      <motion.button 
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        onClick={reset}
                        className="w-full py-4 bg-[#1D1B20] text-white rounded-full font-bold text-base flex items-center justify-center gap-3 shadow-lg transition-all"
                      >
                        <RefreshCw className="w-5 h-5" />
                        Start Over
                      </motion.button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*" 
            className="hidden" 
          />
        </div>

        {/* Home Indicator */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1.5 bg-black/10 rounded-full z-[100]" />
      </div>
    </div>
  );
}
